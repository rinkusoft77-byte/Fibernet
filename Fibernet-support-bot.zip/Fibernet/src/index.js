import { CONTACTS, DIAGNOSTICS, POPULAR_SERVICES, URLS } from "./config.js";
import { t } from "./i18n.js";
import {
  addTicketMessage, claimUpdate, cleanupProcessedUpdates, clearState, closeTicket, createTicket,
  getTicket, getTicketBySupportMessage, getUser, listOpenTickets, listUserTickets, parseStateData,
  releaseUpdate, savePhone, setLanguage, setState, setSupportMessageId, ticketStats, upsertUser
} from "./db.js";
import { getSourceStatus, getTariffs, syncOfficialSources } from "./catalog.js";
import {
  answerCallback, contactKeyboard, copyMessage, editMessage, editReplyMarkup, escapeHtml, inlineKeyboard,
  removeKeyboard, sendMessage, tg
} from "./telegram.js";

function isSupportChat(env, chatId) {
  return String(chatId) === String(env.SUPPORT_CHAT_ID);
}

function isAdmin(env, userId, chatId) {
  if (isSupportChat(env, chatId)) return true;
  const ids = String(env.ADMIN_IDS || "").split(",").map(x => x.trim()).filter(Boolean);
  return ids.includes(String(userId));
}

function homeKeyboard(lang) {
  return inlineKeyboard([
    [{ text: t(lang, "tariffs"), callback_data: "menu:tariffs" }, { text: t(lang, "support"), callback_data: "menu:support" }],
    [{ text: t(lang, "connect"), callback_data: "menu:connect" }],
    [{ text: t(lang, "cabinet"), callback_data: "menu:cabinet" }, { text: t(lang, "contacts"), callback_data: "menu:contacts" }],
    [{ text: t(lang, "services"), callback_data: "menu:services" }, { text: t(lang, "tickets"), callback_data: "menu:tickets" }],
    [{ text: t(lang, "language"), callback_data: "menu:language" }]
  ]);
}

function supportKeyboard(lang) {
  return inlineKeyboard([
    [{ text: t(lang, "noInternet"), callback_data: "support:no_internet" }, { text: t(lang, "slow"), callback_data: "support:slow" }],
    [{ text: t(lang, "wifi"), callback_data: "support:wifi" }, { text: t(lang, "iptv"), callback_data: "support:iptv" }],
    [{ text: t(lang, "billing"), callback_data: "support:billing" }, { text: t(lang, "other"), callback_data: "support:other" }],
    [{ text: t(lang, "back"), callback_data: "menu:home" }]
  ]);
}

function backKeyboard(lang, target = "home") {
  return inlineKeyboard([[{ text: t(lang, "back"), callback_data: `menu:${target}` }]]);
}

function diagnosticKeyboard(lang, category) {
  const rows = [
    [{ text: t(lang, "solved"), callback_data: `diag:${category}:solved` }],
    [{ text: t(lang, "openTicket"), callback_data: `diag:${category}:ticket` }]
  ];
  if (category === "slow") rows.unshift([{ text: t(lang, "speedTest"), url: URLS.speed }]);
  rows.push([{ text: t(lang, "back"), callback_data: "menu:support" }]);
  return inlineKeyboard(rows);
}

function languageKeyboard() {
  return inlineKeyboard([
    [{ text: "🇺🇿 O‘zbekcha", callback_data: "lang:uz" }, { text: "🇷🇺 Русский", callback_data: "lang:ru" }]
  ]);
}

function normalizePhone(message) {
  if (message.contact?.phone_number) return message.contact.phone_number;
  const text = (message.text || "").trim();
  const digits = text.replace(/[^\d+]/g, "");
  return digits.length >= 9 ? digits : null;
}

function fmtPrice(n, lang) {
  const x = Number(n || 0).toLocaleString("ru-RU").replaceAll(",", " ");
  return lang === "ru" ? `${x} сум/мес` : `${x} so‘m/oy`;
}

function formatTariffs(items, lang, series) {
  const labels = lang === "ru"
    ? { evening: "18:00–00:00", day: "00:00–18:00", tasix: "TAS-IX" }
    : { evening: "18:00–00:00", day: "00:00–18:00", tasix: "TAS-IX" };
  const title = series === "tezkor" ? "TEZKOR" : "OnLine";
  const lines = [`📶 <b>${title}</b>`, ""];
  for (const it of items) {
    lines.push(`<b>${escapeHtml(it.name)}</b> — ${fmtPrice(it.price, lang)}`);
    if (it.evening) lines.push(`• ${labels.evening}: <b>${it.evening} Mbit/s</b>`);
    if (it.daytime) lines.push(`• ${labels.day}: <b>${it.daytime} Mbit/s</b>`);
    if (it.tasix) lines.push(`• ${labels.tasix}: <b>${it.tasix} Mbit/s</b>`);
    if (it.router) lines.push(`• ${lang === "ru" ? "Роутер" : "Router"}: ${escapeHtml(it.router)}`);
    if (it.tv) lines.push(`• TV: ${escapeHtml(it.tv)}`);
    lines.push("");
  }
  lines.push(t(lang, "officialSource"));
  return lines.join("\n");
}

function ticketCategoryLabel(category, lang = "uz") {
  const map = {
    no_internet: lang === "ru" ? "Нет интернета" : "Internet yo‘q",
    slow: lang === "ru" ? "Низкая скорость" : "Internet sekin",
    wifi: "Wi‑Fi",
    iptv: "IPTV / TV",
    billing: lang === "ru" ? "Оплата / кабинет" : "To‘lov / kabinet",
    other: lang === "ru" ? "Другая проблема" : "Boshqa muammo",
    connection: lang === "ru" ? "Подключение" : "Ulanish"
  };
  return map[category] || category;
}

async function showHome(env, chatId, lang, messageId = null) {
  const extra = { reply_markup: homeKeyboard(lang) };
  if (messageId) return editMessage(env, chatId, messageId, t(lang, "welcome"), extra);
  return sendMessage(env, chatId, t(lang, "welcome"), extra);
}

async function notifySupport(env, ticketNo) {
  if (!env.SUPPORT_CHAT_ID || String(env.SUPPORT_CHAT_ID).startsWith("REPLACE_")) return null;
  const ticket = await getTicket(env, ticketNo);
  if (!ticket) return null;
  const user = await getUser(env, ticket.telegram_id);
  const text = [
    `🎫 <b>Yangi FiberNet ticket: ${escapeHtml(ticket.ticket_no)}</b>`,
    `Holat: <b>${escapeHtml(ticket.status)}</b>`,
    `Tur: <b>${escapeHtml(ticketCategoryLabel(ticket.category, "uz"))}</b>`,
    `Priority: <b>${escapeHtml(ticket.priority)}</b>`,
    "",
    `👤 ${escapeHtml([user?.first_name, user?.last_name].filter(Boolean).join(" ") || "—")}`,
    `Telegram ID: <code>${ticket.telegram_id}</code>`,
    user?.username ? `Username: @${escapeHtml(user.username)}` : null,
    `📞 ${escapeHtml(ticket.phone || user?.phone || "—")}`,
    `📍 ${escapeHtml(ticket.address || "—")}`,
    `🔐 Abonent login: <code>${escapeHtml(ticket.account_login || "—")}</code>`,
    "",
    `📝 ${escapeHtml(ticket.description)}`,
    "",
    `Operator: shu xabarga <b>Reply</b> qilib javob bering.`
  ].filter(Boolean).join("\n");
  const result = await sendMessage(env, env.SUPPORT_CHAT_ID, text, {
    reply_markup: inlineKeyboard([[{ text: "✅ Ticketni yopish", callback_data: `admin:close:${ticketNo}` }]])
  });
  await setSupportMessageId(env, ticketNo, result.message_id);
  return result;
}

async function beginTicket(env, chatId, user, category) {
  await setState(env, user.telegram_id, "ticket_account", { category });
  await sendMessage(env, chatId, t(user.language, "askAccount"));
}

async function handleUserState(env, message, user) {
  const chatId = message.chat.id;
  const lang = user.language || "uz";
  const state = user.state;
  const data = parseStateData(user);

  if (!state) return false;

  if (state === "ticket_account") {
    if (!message.text) return true;
    data.accountLogin = message.text.trim() === "-" ? null : message.text.trim().slice(0, 80);
    await setState(env, user.telegram_id, "ticket_address", data);
    await sendMessage(env, chatId, t(lang, "askAddress"));
    return true;
  }

  if (state === "ticket_address") {
    if (!message.text) return true;
    data.address = message.text.trim().slice(0, 300);
    await setState(env, user.telegram_id, "ticket_phone", data);
    await sendMessage(env, chatId, t(lang, "askPhone"), { reply_markup: contactKeyboard(t(lang, "sharePhone")) });
    return true;
  }

  if (state === "ticket_phone") {
    const phone = normalizePhone(message);
    if (!phone) {
      await sendMessage(env, chatId, t(lang, "askPhone"), { reply_markup: contactKeyboard(t(lang, "sharePhone")) });
      return true;
    }
    data.phone = phone.slice(0, 40);
    await savePhone(env, user.telegram_id, data.phone);
    await setState(env, user.telegram_id, "ticket_description", data);
    await sendMessage(env, chatId, t(lang, "askDescription"), { reply_markup: removeKeyboard });
    return true;
  }

  if (state === "ticket_description") {
    if (!message.text) return true;
    data.description = message.text.trim().slice(0, 3000);
    const ticketNo = await createTicket(env, {
      telegramId: user.telegram_id,
      category: data.category || "other",
      description: data.description,
      accountLogin: data.accountLogin,
      address: data.address,
      phone: data.phone,
      priority: data.category === "no_internet" ? "high" : "normal"
    });
    await clearState(env, user.telegram_id);
    await sendMessage(env, chatId, t(lang, "ticketCreated", { ticket: ticketNo }), { reply_markup: homeKeyboard(lang) });
    await notifySupport(env, ticketNo);
    return true;
  }

  if (state === "connect_address") {
    if (!message.text) return true;
    data.address = message.text.trim().slice(0, 300);
    await setState(env, user.telegram_id, "connect_phone", data);
    await sendMessage(env, chatId, t(lang, "connectAskPhone"), { reply_markup: contactKeyboard(t(lang, "sharePhone")) });
    return true;
  }

  if (state === "connect_phone") {
    const phone = normalizePhone(message);
    if (!phone) {
      await sendMessage(env, chatId, t(lang, "connectAskPhone"), { reply_markup: contactKeyboard(t(lang, "sharePhone")) });
      return true;
    }
    await savePhone(env, user.telegram_id, phone);
    const ticketNo = await createTicket(env, {
      telegramId: user.telegram_id,
      category: "connection",
      description: lang === "ru" ? "Новая заявка на подключение FiberNet" : "FiberNet’ga yangi ulanish arizasi",
      address: data.address,
      phone,
      priority: "normal"
    });
    await clearState(env, user.telegram_id);
    await sendMessage(env, chatId, t(lang, "connectCreated", { ticket: ticketNo }), { reply_markup: homeKeyboard(lang) });
    await notifySupport(env, ticketNo);
    return true;
  }

  return false;
}

async function handleAdminMessage(env, message) {
  const chatId = message.chat.id;
  const text = message.text || message.caption || "";

  if (message.reply_to_message?.message_id) {
    const ticket = await getTicketBySupportMessage(env, message.reply_to_message.message_id);
    if (ticket && ticket.status === "open") {
      await copyMessage(env, ticket.telegram_id, chatId, message.message_id);
      await addTicketMessage(env, ticket.ticket_no, "operator", message.from?.id, text || "[media]", message.message_id);
      return true;
    }
  }

  if (!text.startsWith("/")) return false;

  if (text === "/tickets" || text.startsWith("/tickets@")) {
    const tickets = await listOpenTickets(env, 12);
    const body = tickets.length ? tickets.map(x => `• <b>${x.ticket_no}</b> — ${escapeHtml(ticketCategoryLabel(x.category))}\n${escapeHtml((x.description || "").slice(0, 120))}`).join("\n\n") : "✅ Ochiq ticket yo‘q.";
    await sendMessage(env, chatId, `🎫 <b>Ochiq ticketlar</b>\n\n${body}`);
    return true;
  }

  if (text === "/stats" || text.startsWith("/stats@")) {
    const s = await ticketStats(env);
    await sendMessage(env, chatId, `📊 <b>Ticket statistikasi</b>\n\nOchiq: <b>${s.open_count || 0}</b>\nYopilgan: <b>${s.closed_count || 0}</b>\nJami: <b>${s.total_count || 0}</b>`);
    return true;
  }

  const replyMatch = text.match(/^\/reply(?:@\w+)?\s+(FN-[A-Z0-9-]+)\s+([\s\S]+)/i);
  if (replyMatch) {
    const ticket = await getTicket(env, replyMatch[1].toUpperCase());
    if (!ticket || ticket.status !== "open") {
      await sendMessage(env, chatId, "Ticket topilmadi yoki yopilgan.");
      return true;
    }
    const body = replyMatch[2].trim();
    await sendMessage(env, ticket.telegram_id, `👨‍💻 <b>FiberNet operatori:</b>\n\n${escapeHtml(body)}`);
    await addTicketMessage(env, ticket.ticket_no, "operator", message.from?.id, body, message.message_id);
    await sendMessage(env, chatId, `✅ ${ticket.ticket_no} ga yuborildi.`);
    return true;
  }

  const closeMatch = text.match(/^\/close(?:@\w+)?\s+(FN-[A-Z0-9-]+)/i);
  if (closeMatch) {
    await adminCloseTicket(env, chatId, message.from?.id, closeMatch[1].toUpperCase());
    return true;
  }

  if (text === "/sync" || text.startsWith("/sync@")) {
    const report = await syncOfficialSources(env);
    const lines = report.map(r => `• ${r.key}: ${r.status}${r.parsed !== undefined ? ` / parsed ${r.parsed}` : ""}`);
    await sendMessage(env, chatId, `🔄 <b>FiberNet source sync</b>\n\n${lines.join("\n")}`);
    return true;
  }

  return false;
}

async function adminCloseTicket(env, chatId, adminId, ticketNo, callbackMessageId = null) {
  const ticket = await getTicket(env, ticketNo);
  if (!ticket) {
    await sendMessage(env, chatId, "Ticket topilmadi.");
    return;
  }
  const changed = await closeTicket(env, ticketNo, adminId);
  if (changed) {
    const user = await getUser(env, ticket.telegram_id);
    const lang = user?.language || "uz";
    const msg = lang === "ru" ? `✅ Ваша заявка <b>${ticketNo}</b> закрыта оператором.` : `✅ <b>${ticketNo}</b> ticket operator tomonidan yopildi.`;
    await sendMessage(env, ticket.telegram_id, msg, { reply_markup: homeKeyboard(lang) });
    await addTicketMessage(env, ticketNo, "system", adminId, "Ticket closed", null);
  }
  const resultText = changed ? `✅ ${ticketNo} yopildi.` : `ℹ️ ${ticketNo} avval yopilgan.`;
  if (callbackMessageId) {
    try {
      await editReplyMarkup(env, chatId, callbackMessageId, { inline_keyboard: [] });
    } catch {}
    await sendMessage(env, chatId, resultText);
  } else {
    await sendMessage(env, chatId, resultText);
  }
}

async function handleCallback(env, q) {
  const chatId = q.message?.chat?.id;
  if (!chatId) return;
  let user = await upsertUser(env, q.from);
  const lang = user.language || "uz";
  const data = q.data || "";
  await answerCallback(env, q.id, "");

  if (data.startsWith("lang:")) {
    const selected = data.split(":")[1] === "ru" ? "ru" : "uz";
    await setLanguage(env, q.from.id, selected);
    await clearState(env, q.from.id);
    return showHome(env, chatId, selected, q.message.message_id);
  }

  if (data === "menu:language") {
    return editMessage(env, chatId, q.message.message_id, t(lang, "chooseLanguage"), { reply_markup: languageKeyboard() });
  }

  if (data === "menu:home") {
    await clearState(env, q.from.id);
    return showHome(env, chatId, lang, q.message.message_id);
  }

  if (data === "menu:tariffs") {
    return editMessage(env, chatId, q.message.message_id, t(lang, "tariffChoose"), {
      reply_markup: inlineKeyboard([
        [{ text: "⚡ TEZKOR", callback_data: "tariffs:tezkor" }, { text: "🌐 OnLine", callback_data: "tariffs:online" }],
        [{ text: t(lang, "allTariffs"), url: URLS.tariffs }],
        [{ text: t(lang, "back"), callback_data: "menu:home" }]
      ])
    });
  }

  if (data.startsWith("tariffs:")) {
    const series = data.split(":")[1];
    const items = await getTariffs(env, series);
    return editMessage(env, chatId, q.message.message_id, formatTariffs(items, lang, series), {
      reply_markup: inlineKeyboard([
        [{ text: t(lang, "connect"), callback_data: "menu:connect" }],
        [{ text: t(lang, "allTariffs"), url: series === "tezkor" ? URLS.tezkor : URLS.online }],
        [{ text: t(lang, "back"), callback_data: "menu:tariffs" }]
      ])
    });
  }

  if (data === "menu:support") {
    await clearState(env, q.from.id);
    return editMessage(env, chatId, q.message.message_id, t(lang, "supportChoose"), { reply_markup: supportKeyboard(lang) });
  }

  if (data.startsWith("support:")) {
    const category = data.split(":")[1];
    const text = DIAGNOSTICS[lang]?.[category] || DIAGNOSTICS.uz.other;
    return editMessage(env, chatId, q.message.message_id, text, { reply_markup: diagnosticKeyboard(lang, category) });
  }

  if (data.startsWith("diag:")) {
    const [, category, action] = data.split(":");
    if (action === "solved") {
      await clearState(env, q.from.id);
      return editMessage(env, chatId, q.message.message_id, t(lang, "solvedThanks"), { reply_markup: homeKeyboard(lang) });
    }
    if (action === "ticket") return beginTicket(env, chatId, user, category);
  }

  if (data === "menu:connect") {
    await setState(env, q.from.id, "connect_address", {});
    await sendMessage(env, chatId, t(lang, "connectAskAddress"));
    return;
  }

  if (data === "menu:cabinet") {
    return editMessage(env, chatId, q.message.message_id, t(lang, "cabinetText"), {
      reply_markup: inlineKeyboard([
        [{ text: t(lang, "cabinet"), url: URLS.cabinet }],
        [{ text: t(lang, "back"), callback_data: "menu:home" }]
      ])
    });
  }

  if (data === "menu:contacts") {
    const address = lang === "ru" ? CONTACTS.addressRu : CONTACTS.addressUz;
    const body = `${t(lang, "contactsTitle")}\n\n📞 <b>${CONTACTS.phone}</b>\n🛠 ${lang === "ru" ? "Техподдержка: 24/7" : "Texnik yordam: 24/7"}\n\n📧 ${CONTACTS.infoEmail}\n🧑‍💻 ${CONTACTS.supportEmail}\n💳 ${CONTACTS.financeEmail}\n\n📍 ${escapeHtml(address)}`;
    return editMessage(env, chatId, q.message.message_id, body, {
      reply_markup: inlineKeyboard([
        [{ text: t(lang, "website"), url: URLS.home }],
        [{ text: t(lang, "back"), callback_data: "menu:home" }]
      ])
    });
  }

  if (data === "menu:services") {
    const body = [t(lang, "servicesTitle"), "", ...POPULAR_SERVICES.map(([name, price]) => `• ${escapeHtml(name)} — <b>${price}</b>`), "", lang === "ru" ? "Актуальную полную стоимость проверяйте на официальном сайте." : "To‘liq va dolzarb narxlarni rasmiy saytdan tekshiring."].join("\n");
    return editMessage(env, chatId, q.message.message_id, body, {
      reply_markup: inlineKeyboard([
        [{ text: t(lang, "website"), url: URLS.services }],
        [{ text: t(lang, "back"), callback_data: "menu:home" }]
      ])
    });
  }

  if (data === "menu:tickets") {
    const tickets = await listUserTickets(env, q.from.id, 8);
    const body = tickets.length ? tickets.map(x => {
      const status = x.status === "open" ? "🟡" : "✅";
      return `${status} <b>${x.ticket_no}</b> — ${escapeHtml(ticketCategoryLabel(x.category, lang))}\n${escapeHtml((x.description || "").slice(0, 100))}`;
    }).join("\n\n") : t(lang, "emptyTickets");
    return editMessage(env, chatId, q.message.message_id, `🎫 <b>${t(lang, "tickets")}</b>\n\n${body}`, { reply_markup: backKeyboard(lang) });
  }

  if (data.startsWith("admin:close:") && isAdmin(env, q.from.id, chatId)) {
    const ticketNo = data.slice("admin:close:".length);
    return adminCloseTicket(env, chatId, q.from.id, ticketNo, q.message.message_id);
  }
}

async function handleMessage(env, message) {
  if (!message.from || message.from.is_bot) return;
  const chatId = message.chat.id;

  if (isAdmin(env, message.from.id, chatId) && isSupportChat(env, chatId)) {
    const handled = await handleAdminMessage(env, message);
    if (handled) return;
  }

  if (message.chat.type !== "private") return;

  let user = await upsertUser(env, message.from);
  const text = (message.text || "").trim();

  if (text === "/start") {
    await clearState(env, message.from.id);
    if (!user?.language) {
      return sendMessage(env, chatId, t("uz", "chooseLanguage"), { reply_markup: languageKeyboard() });
    }
    return showHome(env, chatId, user.language || "uz");
  }

  if (text === "/language") {
    return sendMessage(env, chatId, t(user.language || "uz", "chooseLanguage"), { reply_markup: languageKeyboard() });
  }

  if (text === "/cancel") {
    await clearState(env, message.from.id);
    return sendMessage(env, chatId, t(user.language || "uz", "cancelled"), { reply_markup: homeKeyboard(user.language || "uz") });
  }

  if (text === "/tickets") {
    const tickets = await listUserTickets(env, message.from.id, 8);
    const lang = user.language || "uz";
    const body = tickets.length ? tickets.map(x => `${x.status === "open" ? "🟡" : "✅"} <b>${x.ticket_no}</b> — ${escapeHtml(ticketCategoryLabel(x.category, lang))}`).join("\n") : t(lang, "emptyTickets");
    return sendMessage(env, chatId, `🎫 <b>${t(lang, "tickets")}</b>\n\n${body}`, { reply_markup: homeKeyboard(lang) });
  }

  user = await getUser(env, message.from.id);
  if (await handleUserState(env, message, user)) return;

  await sendMessage(env, chatId, t(user.language || "uz", "unknown"), { reply_markup: homeKeyboard(user.language || "uz") });
}

async function handleUpdate(env, update) {
  if (update.callback_query) return handleCallback(env, update.callback_query);
  if (update.message) return handleMessage(env, update.message);
}

async function webhook(request, env) {
  const expected = env.TELEGRAM_WEBHOOK_SECRET;
  const received = request.headers.get("X-Telegram-Bot-Api-Secret-Token");
  if (!expected || received !== expected) return new Response("Unauthorized", { status: 401 });

  let update;
  try { update = await request.json(); }
  catch { return new Response("Bad Request", { status: 400 }); }
  if (!Number.isInteger(update.update_id)) return new Response("ok");

  const claimed = await claimUpdate(env, update.update_id);
  if (!claimed) return new Response("ok");
  try {
    await handleUpdate(env, update);
    return new Response("ok");
  } catch (err) {
    console.error("update_failed", update.update_id, err?.stack || String(err));
    await releaseUpdate(env, update.update_id);
    return new Response("Retry", { status: 500 });
  }
}

async function health(env) {
  try {
    const row = await env.DB.prepare("SELECT COUNT(*) AS count FROM users").first();
    const sources = await getSourceStatus(env);
    return Response.json({ ok: true, service: "fibernet-support-bot", users: row?.count || 0, sources });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 503 });
  }
}

async function adminSync(request, env) {
  const auth = request.headers.get("authorization") || "";
  if (!env.ADMIN_API_TOKEN || auth !== `Bearer ${env.ADMIN_API_TOKEN}`) return new Response("Unauthorized", { status: 401 });
  const report = await syncOfficialSources(env);
  return Response.json({ ok: true, report });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "POST" && url.pathname === "/telegram/webhook") return webhook(request, env);
    if (request.method === "GET" && url.pathname === "/health") return health(env);
    if (request.method === "POST" && url.pathname === "/admin/sync") return adminSync(request, env);
    if (request.method === "GET" && url.pathname === "/") {
      return new Response("FiberNet Support Bot is running.", { headers: { "content-type": "text/plain; charset=utf-8" } });
    }
    return new Response("Not found", { status: 404 });
  },

  async scheduled(_controller, env, ctx) {
    ctx.waitUntil((async () => {
      await syncOfficialSources(env);
      await cleanupProcessedUpdates(env);
    })());
  }
};
